# TEDxYouth@LincolnStreet Website

This is our in-redesign website (as it stands). It contains a QR-based ticketing system that uses Stripe, SendGrid, and a companion iOS app (see CheckIn repository) to get people tickets and check them in quickly.

Required:
- CheckIn App (Check people in at the door)
- SendGrid API Key (Email)
- Stripe Account (Payments)
- Firebase (Hosting)

You can see last year's website [here.](tedxyouthls.com)
